headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer ea62e13a-e978-4100-b28d-d5b3d66fe373' }




user_body = {
    "firstName": "Анатолий",
    "phone": "+79995553322",
    "address": "г. Москва, ул. Пушкина, д. 10"
}



product_ids = {"ids": [1, 2, 3]}

kits_body = {"name": "Мой_набор"}

